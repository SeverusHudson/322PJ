/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing a list of open data department.
*/

import SwiftUI

struct openList: View {
    @EnvironmentObject private var userData: UserData
    
    var body: some View {
        List {
            Toggle(isOn: $userData.showFavoritesOnly) {
                Text("Show Favorites Only")
            }
            
            ForEach(userData.opendata) { opendata in
                if !self.userData.showFavoritesOnly || opendata.isFavorite {
                    NavigationLink(
                        destination: openDetail(opendata: opendata)
                            .environmentObject(self.userData)
                    ) {
                        openRow(opendata: opendata)
                    }
                }
            }
        }
        .navigationBarTitle(Text("Departments"))
    }
}

struct openList_Previews: PreviewProvider {
    static var previews: some View {
        ForEach(["iPhone SE", "iPhone XS Max"], id: \.self) { deviceName in
            NavigationView {
                openList()
            }
            .previewDevice(PreviewDevice(rawValue: deviceName))
            .previewDisplayName(deviceName)
        }
        .environmentObject(UserData())
    }
}

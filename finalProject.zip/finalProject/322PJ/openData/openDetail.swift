/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view showing the details for a landmark.
*/

import SwiftUI

struct openDetail: View {
    @EnvironmentObject var userData: UserData
    var opendata: openData
    
    var opendataIndex: Int {
        userData.opendata.firstIndex(where: { $0.id == opendata.id })!
    }
    
    var body: some View {
        VStack {
            MapView(coordinate: opendata.locationCoordinate)
                .edgesIgnoringSafeArea(.top)
                .frame(height: 300)
            
            CircleImage(image: opendata.image)
                .offset(x: 0, y: -130)
                .padding(.bottom, -130)
            
            VStack(alignment: .leading) {
                HStack {
                    Text(opendata.name)
                        .font(.title)
                    
                    Button(action: {
                        self.userData.opendata[self.opendataIndex]
                            .isFavorite.toggle()
                    }) {
                        if self.userData.opendata[self.opendataIndex]
                            .isFavorite {
                            Image(systemName: "star.fill")
                                .foregroundColor(Color.yellow)
                        } else {
                            Image(systemName: "star")
                                .foregroundColor(Color.gray)
                        }
                    }
                }
                
                HStack(alignment: .top) {
                    Text(opendata.department)
                        .font(.subheadline)
                    Spacer()
                    Text(opendata.pro)
                        .font(.subheadline)
                }
            }
            .padding()
            
            Spacer()
        }
    }
}

struct openDetail_Previews: PreviewProvider {
    static var previews: some View {
        let userData = UserData()
        return openDetail(opendata: userData.opendata[0])
            .environmentObject(userData)
    }
}

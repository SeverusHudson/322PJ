//
//  ProfileEditor.swift
//  322PJ
//
//  Created by Henry Zhang on 2020/08/12.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct ProfileEditor: View {
    @Binding var profile: Profile
    var dateRange: ClosedRange<Date>{
        let min = Calendar.current.date(byAdding: .year, value: -1, to: profile.birthday)!
        let max = Calendar.current.date(byAdding: .year, value: -1, to: profile.birthday)!
        
        return min...max
    }
    var body: some View {
        List{
            HStack{
                Text("Username").bold()
                Divider()
                TextField("Username", text: $profile.username)
            }
            
            Toggle(isOn: $profile.prefersNotifications){
                Text("Enable Notifications")
            }
            
            VStack(alignment: .leading, spacing: 20){
                Text("Feeling").bold()
                
                Picker("Feeling", selection: $profile.feeling){
                    ForEach(Profile.feeling.allCases, id: \.self){ feeling in
                        Text(feeling.rawValue).tag(feeling)
                        
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            .padding(.top)
            
            VStack(alignment: .leading, spacing: 20){
                Text("Birthday").bold()
                DatePicker(
                    "Birthday",
                    selection: $profile.birthday,
                    in: dateRange,
                    displayedComponents: .date
                )
            }
        }
    }
}

struct ProfileEditor_Previews: PreviewProvider {
    static var previews: some View {
        ProfileEditor(profile: .constant(.default))
    }
}

//
//  HikeBadge.swift
//  Landmarks
//
//  Created by Henry Zhang on 2020/08/12.
//  Copyright © 2020 Apple. All rights reserved.
//

import SwiftUI

struct readBadge: View {
    var name: String
    
    var body: some View {
        VStack(alignment: .center){
            Badge()
                .frame(width: 300, height: 300)
                .scaleEffect(1.0/3.0)
                .frame(width: 100, height: 100)
            Text(name)
                .font(.caption)
                .accessibility(label: Text("Badge for \(name)."))
        }
    }
}

struct readBadge_Previews: PreviewProvider {
    static var previews: some View {
        readBadge(name: "Preview Testing")
    }
}

/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A model object that stores user profile data.
*/

import Foundation

struct Profile {
    var username: String
    var prefersNotifications: Bool
    var feeling: feeling
    var birthday: Date
    
    static let `default` = Self(username: "Henry Zhang", prefersNotifications: true, feeling: .sad)
    
    init(username: String, prefersNotifications: Bool = true, feeling: feeling = .sad) {
        self.username = username
        self.prefersNotifications = prefersNotifications
        self.feeling = feeling
        self.birthday = Date()
    }
    
    enum feeling: String, CaseIterable {
        case happy = "😃"
        case sad = "😞"
        case angry = "😡"
        case bless = "😇"
    }
}

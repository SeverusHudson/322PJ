/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The model for a hike.
*/

import SwiftUI

struct Read: Codable, Hashable, Identifiable {
    var name: String
    var id: Int
    var files: Int
    var difficulty: Int
    var observations: [Observation]

    static var formatter = LengthFormatter()


    struct Observation: Codable, Hashable {
        var fileFromStart: Double
        
        var elevation: Range<Double>
        var pace: Range<Double>
        var heartRate: Range<Double>
    }
}

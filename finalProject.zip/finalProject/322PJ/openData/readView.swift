/*
See LICENSE folder for this sample’s licensing information.

Abstract:
A view displaying information about reading files, including an elevation graph.
*/

import SwiftUI

struct readView: View {
    var read: Read
    @State private var showDetail = false
    
    var transition: AnyTransition {
        let insertion = AnyTransition.move(edge: .trailing)
            .combined(with: .opacity)
        let removal = AnyTransition.scale
            .combined(with: .opacity)
        return .asymmetric(insertion: insertion, removal: removal)
    }
    
    var body: some View {
        VStack {
            HStack {
                readGraph(read: read, path: \.elevation)
                    .frame(width: 50, height: 30)
                    .animation(nil)
                
                VStack(alignment: .leading) {
                    Text(read.name)
                        .font(.headline)
                }
                
                Spacer()

                Button(action: {
                    withAnimation {
                    	self.showDetail.toggle()
                    }
                }) {
                    Image(systemName: "chevron.right.circle")
                        .imageScale(.large)
                        .rotationEffect(.degrees(showDetail ? 90 : 0))
                        .scaleEffect(showDetail ? 1.5 : 1)
                        .padding()
                }
            }

            if showDetail {
                readDetail(read: read)
                	.transition(transition)
            }
        }
    }
}

struct readView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            readView(read: readData[0])
                .padding()
            Spacer()
        }
    }
}
